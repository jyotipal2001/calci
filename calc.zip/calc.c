#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
int k=0,result=0;
int menu(){
	int ch;
	printf("\n1.add");
	printf("\n2.sub");
	printf("\n3.mul");
	printf("\n4.Div");
	printf("\n5.getrim");
	printf("\n6.clear");
	printf("\n7.exit");
	printf("\n enter your choice");
	scanf("%d",&ch);
	return(ch);
}
void add(){
	int a,b;
	if(k){
		printf("enter a number:");
		scanf("%d",&a);
		result+=a;
		printf("\n result=%d",result);
		
	}
	else{
		printf("\n enter a two numbers:");
		scanf("%D%D",&a,&b);
		result=a+b;
		printf("\nresult=%d",result);
	}
}
void sub(){
	int a,b;
	if(k){
		printf("enter a number:");
		scanf("%d",&a);
		result-=a;
		printf("\n result=%d",result);
		
	}
	else{
		printf("\n enter a two numbers:");
		scanf("%d%d",&a,&b);
		result=a-b;
		printf("\nresult=%d",result);
	}
}
void mul(){
	int a,b;
	if(k){
		printf("enter a number:");
		scanf("%d",&a);
		result*=a;
		printf("\n result=%d",result);
		
	}
	else{
		printf("\n enter a two numbers:");
		scanf("%d%d",&a,&b);
		result=a*b;
		printf("\nresult=%d",result);
	}
}
void Div(){
	int a,b;
	if(k){
		printf("enter a number:");
		scanf("%d",&a);
		result/=a;
		printf("\n result=%d",result);
		
	}
	else{
		printf("\n enter a two numbers:");
		scanf("%d%d",&a,&b);
		result=a/b;
		printf("\nresult=%d",result);
	}
}
void rim(){
	int a,b;
	if(k){
		printf("enter a number:");
		scanf("%d",&a);
		result%=a;
		printf("\n result=%d",result);
		
	}
	else{
		printf("\n enter a two numbers:");
		scanf("%d%d",&a,&b);
		result=a%b;
		printf("\nresult=%d",result);
	}
}
void clear(){
	printf("\nold data clear");
	result=0;
	k=0;
}
int main(){
	while(1){
	system("cls");
	printf("\n\n   old result=%d",result);
	switch(menu()){
		case 1:
			add();
			k=1;
			break;
			case 2:
				sub();
				k=1;
				break;
				case 3:
					mul();
					k=1;
					break;
					case 4:
						Div();
						k=1;
						break;
						case 5:
							rim();
							k=1;
							break;
							case 6:
								clear();
								break;
								case 7:
									exit(0);
									default:
										printf("\n invalid choice");
	}
	getch();
}
}
